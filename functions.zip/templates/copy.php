<?php 
/*
Template Name: Политика конфиденциальности
*/
get_header(); ?>

<main class="main">

  <section class="copy page-section">
    <div class="container">
      <h2 class="title">Политика защиты персональных данных</h2>
      <div class="copy__text">
        <?php the_field('copy'); ?>
      </div>
    </div>
  </section>

</main>

<?php get_footer(); ?>